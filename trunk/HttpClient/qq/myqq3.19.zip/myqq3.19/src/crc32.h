#ifndef _CRC32_H
#define _CRC32_H

uint crc32( uchar *buf, int len);



#endif
